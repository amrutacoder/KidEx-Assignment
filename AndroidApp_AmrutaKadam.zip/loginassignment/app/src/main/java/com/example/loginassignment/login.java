package com.example.loginassignment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Set the correct layout

        EditText e1 = findViewById(R.id.etEmail);
        EditText p1 = findViewById(R.id.etPassword);
        Button b1 = findViewById(R.id.btnLogin);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = e1.getText().toString().trim();
                String password = p1.getText().toString().trim();

                if (email.equals("Amruta Kadam") && password.equals("Amruta@123")) {
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.putExtra("Username", email);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(login.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
